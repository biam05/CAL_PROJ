#ifndef SRC_HOUSES_H
#define SRC_HOUSES_H

class House {
    int vertex;

public:
    House (int v) : vertex(v) {};

    int getVertex() const;
};
#endif //SRC_HOUSES_H
