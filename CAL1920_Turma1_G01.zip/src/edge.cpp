#include <edge.h>

float Edge::getWeight() {
    return weight;
}

int Edge::getID() {
    return ID;
}

int Edge::getVi() {
    return vi;
}

int Edge::getVf() {
    return vf;
}

