#include "house.h"

int House::getVertex() const {
    return vertex;
}